
__author__ = "Jerome Leclanche"
__email__ = "jerome@leclan.ch"
__version__ = "1.0.0"


class NotificationError(Exception):
    pass
